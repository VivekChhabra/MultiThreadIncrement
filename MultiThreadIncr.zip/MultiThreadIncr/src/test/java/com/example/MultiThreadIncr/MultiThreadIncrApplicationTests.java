package com.example.MultiThreadIncr;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MultiThreadIncrApplicationTests {

	@Test
	void contextLoads() {
	}

}
