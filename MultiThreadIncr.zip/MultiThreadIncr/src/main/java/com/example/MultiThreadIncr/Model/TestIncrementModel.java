package com.example.MultiThreadIncr.Model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="test_increment")
public class TestIncrementModel {

	@Id
	@Column(name ="ID")
	public int id;
	
	@Column(name = "INCR")
	private int incr;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getIncr() {
		return incr;
	}

	public void setIncr(int incr) {
		this.incr = incr;
	}

	
	
	
}
