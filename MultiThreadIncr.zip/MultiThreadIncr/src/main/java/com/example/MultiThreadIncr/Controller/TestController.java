package com.example.MultiThreadIncr.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.MultiThreadIncr.Service.MultiThreadService;



@RestController
@RequestMapping(value = "/update")
public class TestController {

	@Autowired
	MultiThreadService obj;

	@RequestMapping(value = "/test", method = RequestMethod.POST)
	public String updateInt(@RequestParam int updateCounter) {
		
		return obj.updateInt(updateCounter);
	
	}

}
