package com.example.MultiThreadIncr.ServiceImpl;

import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.MultiThreadIncr.Model.TestIncrementModel;
import com.example.MultiThreadIncr.Repository.TestIncrementModelRepository;
import com.example.MultiThreadIncr.Service.MultiThreadService;

@Service
public class MultiThreadIncrServImpl implements MultiThreadService {
	@Autowired
	TestIncrementModelRepository rep;
	Logger logger = LoggerFactory.getLogger(MultiThreadIncrServImpl.class);

	public  String updateInt(int counter) {

		

			UpdateIncrTable obj = new UpdateIncrTable(rep,counter);
			obj.start();

//			try {
//				Thread.sleep(500);
//			} catch (InterruptedException e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//			}
		
		return "Success";

	}

}

class UpdateIncrTable extends Thread {

	TestIncrementModelRepository rep;
	int counter1;

	UpdateIncrTable(TestIncrementModelRepository object,int counter) {
		rep = object;
		counter1 = counter;
	}

	Logger logger = LoggerFactory.getLogger(UpdateIncrTable.class);

	// private volatile int idVal=1;
	@Override
	public void run() {
		
			// TestIncrementModel ob =new TestIncrementModel();
			
			Optional<TestIncrementModel> optionalNumber = rep.findById(1);
			if (optionalNumber.isPresent()) {
				TestIncrementModel number = optionalNumber.get();
				//System.out.println("number is : " +number.getIncr() );
				int updatedCount = number.getIncr();
				synchronized(rep) { 
				for(int i=0;i<counter1; i++) {
					 {
						 updatedCount+=1;
					 }
				}
				number.setIncr(updatedCount);
				rep.save(number);
				 }
			}

			// rep.setNewIncrForTestIncrementModel(1);
//		} catch (Exception e) {
//			logger.error("Exception occurred while incrementing counter", e);
//			throw e;
//		}

	}
}
