package com.example.MultiThreadIncr.Service;

import org.springframework.stereotype.Service;

@Service
public interface MultiThreadService {

	
	String updateInt(int counter);
	
}
