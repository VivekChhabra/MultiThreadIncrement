package com.example.MultiThreadIncr.Repository;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.MultiThreadIncr.Model.TestIncrementModel;

@Repository
@Transactional
public interface TestIncrementModelRepository extends JpaRepository<TestIncrementModel, Integer>
{
	
}
